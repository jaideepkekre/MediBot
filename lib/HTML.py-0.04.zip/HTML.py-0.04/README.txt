HTML.py

This module provides a few classes to easily generate HTML tables and lists.

Author: Philippe Lagadec

Project website: http://www.decalage.info/python/html

License: CeCILL (open-source GPL compatible), see source code for details.
         http://www.cecill.info

-------------------------------------------------------------------------------

INSTALLATION:

- on Windows, double-click on install.bat, or type "setup.py install" in a CMD
  window.
- on other systems, type "python setup.py install" in a shell.

-------------------------------------------------------------------------------

HOW TO USE THIS MODULE:

First have a look at HTML_tutorial.py. It provides examples of how to use
HTML.py.
See http://www.decalage.info/python/html for additional information and updates.
For complete reference see HTML.py.html, and also the source code of HTML.py.


